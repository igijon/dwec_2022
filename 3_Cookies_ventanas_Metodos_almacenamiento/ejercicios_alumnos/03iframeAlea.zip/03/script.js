function cambiarColor() {
    color = elegirColor();
    document.getElementsByTagName('iframe')[0].style.backgroundColor = color;
}

function elegirColor() {
    let r = Math.trunc((Math.random()) * 256);
    let g = Math.trunc((Math.random()) * 256);
    let b = Math.trunc((Math.random()) * 256);
    let color = 'rgb(' + r + ',' + g + ',' + b +')';
    return color;
}