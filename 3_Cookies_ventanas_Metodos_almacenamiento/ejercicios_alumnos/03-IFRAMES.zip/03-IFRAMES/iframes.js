/*function colores() {

    for (var i = 0; i < 10; i++) {
        setTimeout(() => {
            var alea = Math.random() * 3;
            alea = Math.trunc(alea);
            var iframe = document.getElementsByTagName('iframe')[0];

            switch (alea) {
                case 0:
                    iframe.style.backgroundColor = 'blue';
                    iframe.contentWindow.document.body.style.backgroundColor = 'blue';
                    break;
                case 1:
                    iframe.style.backgroundColor = 'red';
                    iframe.contentWindow.document.body.style.backgroundColor = 'red';
                    break;
                case 2:
                    iframe.style.backgroundColor = 'green';
                    iframe.contentWindow.document.body.style.backgroundColor = 'green';
                    break;
            }

        }, 1000)
    }
}*/

function tiempo() {
    setInterval(colores, 1000);
}


function colores() {


    var alea = Math.random() * 7;
    alea = Math.trunc(alea);
    var iframe = document.getElementsByTagName('iframe')[0];

    switch (alea) {
        case 0:
            iframe.contentWindow.document.body.style.backgroundColor = 'blue';
            break;
        case 1:
            iframe.contentWindow.document.body.style.backgroundColor = 'red';
            break;
        case 2:
            iframe.contentWindow.document.body.style.backgroundColor = 'green';
            break;
        case 3:
            iframe.contentWindow.document.body.style.backgroundColor = 'yellow';
            break;
        case 4:
            iframe.contentWindow.document.body.style.backgroundColor = 'blueviolet';
            break;
        case 5:
            iframe.contentWindow.document.body.style.backgroundColor = 'midnightblue';
            break;
        case 6:
            iframe.contentWindow.document.body.style.backgroundColor = 'wheat';
            break;
    }

}