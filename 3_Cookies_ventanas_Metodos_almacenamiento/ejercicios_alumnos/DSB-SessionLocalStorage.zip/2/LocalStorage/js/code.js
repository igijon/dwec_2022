/**
 * LocalStorage y sessionStorage
 * El objetivo de esta actividad es utilizar el objeto localStorage 
 * para guardar información de forma persistente y aprovecharlo para 
 * hacer comunicación entre dos páginas web.
 * En esta actividad repetiréis la anterior, pero en vez de usar cookies 
 * utilizará localStorage, con los métodos setItemt y getItem.
 * Además, localStorage permite otras opciones, como lanzar eventos una respuesta
 * a un cambio de valor de alguna variable.
 * Puede utilizar localStorage cuando sólo necesita estas variables
 * en el lado del cliente. Pero si las necesita en el lado del servidor
 * utilizaremos cookies, ya que estas viajan en la cabecera de las llamadas HTTP,
 * y existen funciones de PHP o de JAVA para gestionar las cookies en el servidor.
 * Realiza el ejercicio también con sessionStorage.
 */

function cambiarFuente(x) {
    localStorage.setItem("fuente", x);
}

function cambiarColor(x) {
    localStorage.setItem("color",x);
}


window.addEventListener('storage', function(event) {
    alert("hola");
    if(event.key == "color"){
        document.getElementById("texto").style.color = event.newValue;
    } else if(event.key == "fuente") {
        document.getElementById("texto").style.fontFamily = event.newValue;
    }
});