/**
                                Cookies 
El objetivo de esta actividad es profundizar en el uso de las Cookies como medio de 
comunicación entre dos páginas web.
Haga dos páginas web:
• En la primera pondréis el primer párrafo del Tirant lo Blanc
• En la segunda, el primer párrafo de Don Quijote de la Mancha
En cada página pondréis dos botones:
• Uno que cambiará el color del texto a través de una cookie.
• Uno que cambiará la fuente del texto a través de una cookie.
En la primera página los botones cambiarán, respectivamente, el color rojo y la fuente Arial.
En la segunda página los botones cambiarán, también respectivamente, el color azul y la 
fuente Verdana.
Cuando se pulse uno de estos botones, la página que lo contiene almacenará una cookie 
con la información del cambio realizado y eliminará la información de los cambios 
anteriores del mismo tipo (color o fuente). De este modo, en cargarse cualquiera de las dos 
páginas, estas consultarán las Cookies y aplicarán a su texto el último cambio realizado (si 
los hay) por alguna de estas páginas tanto en color como la fuente a su texto. Y ello con 
independencia de la página que haya grabado la cookie.
Así, con las Cookies, se almacena la información y se envía entre las dos páginas.
*/

function cambiarFuente(x) {
    document.cookie = "fuente="+x+"; Samesite=None; secure";
}

function cambiarColor(x) {
    document.cookie = "color="+x+"; Samesite=None; secure";
}

function recuperarCookies() {
    var arrayCookies = document.cookie.split('; ');
    for (let i = 0; i < arrayCookies.length; i++) {
        var e = arrayCookies[i].split("=");
        //console.log("Cookie "+ i + ": "+ arrayCookies[i]);
        if(e[0] == "color"){
            document.getElementById("texto").style.color = e[1];
        } else if(e[0] == "fuente") {
            document.getElementById("texto").style.fontFamily = e[1];
        }
        
    }

}