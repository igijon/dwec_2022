var letras;
var letrasOcultas = [];
var intentos = 0;
var palabra;
document.formularioAdivinar.style = "display:none;";
function escribePalabra(){
    palabra = (document.getElementById("palabra").value).toLowerCase();
    //console.log(palabra);
    //document.getElementById('palabraBuena').innerHTML = 'La palabra a acertar era: ' + palabra;
    document.formularioIntro.style = "display:none;"; //Lo oculta del todo sin dejar espacio en su lugar
    letras = palabra.split(""); //separa por carácteres
    for (var i = 0; i < letras.length;i++){
        letrasOcultas.push("_"); //agrega un nuevo elemento
        document.getElementById("palabraOculta").innerHTML += " "+ letrasOcultas[i] + " ";
    }
    intentos = letras.length;
    document.getElementById('intentos').innerHTML = 'Te quedan: ' + intentos + ' intentos';
    document.formularioAdivinar.style = "display:true;"; //es visible
    
    //console.log(letras.length);
}
function escribeLetra(){
    var letraEscrita = (document.getElementById("letra").value).toLowerCase();
    var encontrada = false;
    var ganador = true;
    for (var i = 0; i< letras.length; i++){
        if (letras[i]==letraEscrita ){
            encontrada=true;
            letrasOcultas[i] = letras[i];
            document.getElementById("palabraOculta").innerHTML="";
            for (var j = 0; j < letrasOcultas.length; j++){
                document.getElementById("palabraOculta").innerHTML += " "+ letrasOcultas[j] + " ";
            }
            document.getElementById("palabraBuena").innerHTML = 'Has encontrado la letra: ' + letraEscrita;
        }
    }
    //variable para controlar si no se ha encontrado. Después de hacer la primera comprobación.
    if (!encontrada) {
        document.getElementById("palabraBuena").innerHTML = 'No has encontrado ninguna letra';
        intentos--;
        document.getElementById('intentos').innerHTML = 'Te quedan: ' + intentos + ' intentos';
    }
    if (intentos < 0){
        document.getElementById("intentos").innerHTML = 'Has perdido, la palabra que buscabas era: ' + palabra;
        document.getElementById("botAdivinar").disabled = true;
        intentos = 0;
    }
    for (i = 0; i < letras.length; i++){
        if (letras[i] != letrasOcultas[i])
            ganador = false;
    }
    if (ganador) {
        document.getElementById("palabraBuena").innerHTML = 'HAS GANADO';
        document.getElementById('intentos').innerHTML = '';
        document.getElementById("botAdivinar").disabled = true;
    }

    document.getElementById("letra").value = "";
}
//FALTA POR CORREGIR:
//CUANDO GANO, LOS INTENTOS SIGUEN ACTIVOS
//BOTÓN PARA RESETEAR LA PARTIDA -> RENDIRSE