var INTENTOS = 0;
var NUMPALABRAS = 0;
var UNICO = 0;
var palabraOculta = '';
var palabraUsuario = ''
var pista = '';
var Repeat = '';


/*Como he conseguido mantener el valor de las variables? : lo mire en este foro que encontre;
https://es.stackoverflow.com/questions/181532/c%C3%B3mo-mantener-el-valor-de-una-variable-de-javascript-al-actualizar-la-p%C3%A1gina */

/*Esta funcion sirve para recuperar los datos de la pagina de inicio en la pagina de Ahorcado */
function recuperarDatos() {
    if (UNICO == 0) {
        pista = sessionStorage.getItem('piGuardada');
        palabraOculta = sessionStorage.getItem('palGuardada');
        INTENTOS = sessionStorage.getItem('intGuard');

        document.getElementById('pi').value = pista;
        document.getElementById('inte').value = INTENTOS;
        document.getElementById('numlet').value = INTENTOS;
        NUMPALABRAS = INTENTOS;
        UNICO = 1;
    }
}

/*-------------------------------------------------------------------------------------------*/
/*La funcion Adivinar sirve, en primer lugar para poner en minuscula la palabra del usuario y 
tambien sirve para controlar que el usuario, o mete una letra, o la palabra entera, finalmente
me envia a la funcion Jugar para empezar el juego*/
/*-------------------------------------------------------------------------------------------*/

function Adivinar() {
    var cont = 0;

    palabraUsuario = document.getElementById('pal').value;
    palabraUsuario = palabraUsuario.toLowerCase();

    for (i = 0; i < palabraUsuario.length; i++) {
        cont++;
    }
    if (cont > 1 && cont < palabraOculta.length - 1) {
        alert('solo se permite 1 letra o una palabra entera');
    } else {
        Jugar();
    }

}

/*-------------------------------------------------------------------------------------------*/
/*La funcion Jugar nos permite comenzar el juego, ver si el usuario ha ganado, perdido, si ha acertado
alguna letra...*/
/*-------------------------------------------------------------------------------------------*/

function Jugar() {
    var esEncontrada = false;
    var repetida = false;


    if (palabraUsuario == palabraOculta || NUMPALABRAS == 1) {
        alert('HAS GANADO');
        window.location.href = './Inicio.html';
    } else {
        repetida = Recoger(palabraUsuario);
        if (!repetida) {
            for (var i = 0; i < palabraOculta.length; i++) {

                var letra = palabraOculta.charAt(i);

                if (letra == palabraUsuario) {
                    esEncontrada = true;
                    NUMPALABRAS--;
                    document.getElementById('numlet').value = NUMPALABRAS;
                    pista = pista.substring(0, i) + letra + pista.substring(i + 1);
                    document.getElementById('pi').value = pista;


                }
            }
        } else {
            alert('Esta palabra ya ha sido introducida, introduzca otra');
        }
    }
    if (esEncontrada == false && repetida == false) {
        INTENTOS--;
        document.getElementById('inte').value = INTENTOS;
    }
    if (INTENTOS == 0) {
        alert('HAS PERDIDO . La palabra era: ' + palabraOculta);
        window.location.href = './Inicio.html';
    }
}

/*-------------------------------------------------------------------------------------------*/

/*Esta funcion sirve para controlar que no esta el campo de la palabra oculta vacio,
me reedirecciona a la pagina del juego y almacena el valor de las variables para que no se pierdan*/
/*-------------------------------------------------------------------------------------------*/

function ControlInicio() {

    palabraOculta = document.getElementById('palOc').value;

    if (palabraOculta == '') {
        alert('No puedes continuar');
    } else {
        window.location.href = './Ahorcado.html';
        pista = GenerarPista();
        sessionStorage.setItem('piGuardada', pista);
        sessionStorage.setItem('palGuardada', palabraOculta);
        sessionStorage.setItem('intGuard', INTENTOS);
    }
}

/*-------------------------------------------------------------------------------------------*/
/*Esta funcion sirve para generar la pista y los intentos en funcion de la palabra Oculta*/
/*-------------------------------------------------------------------------------------------*/
function GenerarPista() {
    var pistaAux = '';

    for (var i = 0; i < palabraOculta.length; i++) {

        INTENTOS++;
        pistaAux = pistaAux + '*';
    }
    return pistaAux;
}

/*-------------------------------------------------------------------------------------------*/
/*Esta funcion sirve para comprobar que el usuario no ha repetido una letra usando la variable global
Repeat como una base de datos*/
/*-------------------------------------------------------------------------------------------*/

function Recoger(letra) {
    TeEncontre = false;

    if (Repeat == '') {
        Repeat = Repeat + letra;
    } else {
        for (var i = 0; i < Repeat.length; i++) {
            var letraAux = Repeat.charAt(i);
            if (letraAux == letra) {
                TeEncontre = true;
            }
        }
    }
    if (TeEncontre == false) {
        Repeat = Repeat + letra;
    }


    return TeEncontre;
}