/*
Desarrolla una aplicación que permita calcular los salarios mensuales
de los trabajadores de una empresa a partir de los siguientes datos:
a. Número de horas trabajadas.
b. Turno realizado: Mañanas (m), Tardes (t) o Noches (n).
Para el cálculo del salario bruto se tendrá en cuenta que el
turno de mañana se paga a 15€/hora, 
el de tarde se paga a 17 €/hora y 
el turno de noche se paga 20 €/ hora.

Para el cálculo del salario neto se realizan determinados descuentos destinados 
al pago de impuestos de la siguiente forma:
-Si el salario bruto es menor de 600 € el descuento es del 8%.
-Si el salario bruto está entre 600 € y 1000 € el descuento es del 10%. 
-Si el salario bruto es mayor de 10000 € el descuento es del 12%.
Se desea calcular el salario neto de cada trabajador. Para ello la aplicación irá pidiendo
uno a uno los trabajadores hasta que el usuario indique lo contrario. Para cada trabajador 
se mostrará su salario neto.
Antes de finalizar la aplicación mostrará el importe total de salarios abonados.
El script se escribirá usando tantas funciones como sea posible con el fin de poder
reutilizar la máxima cantidad de código en un futuro.
 */

function main(){
    var trabajadores = [];
    var salariosNetos = [];
    do {
        var nombre = window.prompt("Introduce el nombre del trabajador");
        //console.log("Nombre: " + nombre);
        var turno = window.prompt("Introduce el turno ([M] para mañanas, [T] para tardes, [N] para noches");
        //console.log("Turno:" + turno);
        var horas = window.prompt("Introduce las horas trabajadas");
        //console.log("Horas: " + horas);
        trabajadores.push(nombre);
        var salB = salarioBruto(turno, horas);
        var salN = salarioNeto(salB);
        salariosNetos.push(salN);
        total = total + salN;
        // console.log("Salario bruto: " + salB);
        // console.log("Salario neto: " + salN);
    } while (window.prompt("¿Desea añadir otro trabajador? [S]/[N]").toString().toLowerCase().includes("s"));

    imprimir(trabajadores, salariosNetos);

}

function salarioBruto(turno, horasTrabajadas){
    switch (turno.toLowerCase()) {
        case "m":
            return horasTrabajadas * 15;
        case "t":
            return horasTrabajadas * 17;
        case "n":
            return horasTrabajadas * 20;
        default:
            return 0;
    }
}

function salarioNeto(salarioBruto){
    if (salarioBruto < 600){
        return salarioBruto - (salarioBruto * 0.08);
    } else if(salarioBruto > 600 && salarioBruto < 1000) {
        return salarioBruto - (salarioBruto * 0.1)
    } else if(salarioBruto > 1000){
        return salarioBruto - (salarioBruto * 0.12);
    }
}

function imprimir(trabajadores, salariosNetos){
    if(trabajadores.length == salariosNetos.length) {
        for (let i = 0; i < trabajadores.length; i++) {
            var p = document.createElement("p");
            p.innerHTML = "Nombre: " + trabajadores[i] + "--> Salario: " + salariosNetos[i];
            document.body.appendChild(p);
        }
    }else{
        console.log("Se ha producido un error");
    }
}