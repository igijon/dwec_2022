var salTotal = 0;

function pulsarCalcular() {
    var horas = document.getElementById("horas").value;
    var salBruto;
    var turno;
    var botones = document.getElementsByName("turno");
    for (let i = 0; i < botones.length; i++) {
        if (botones[i].checked) {
            turno = botones[i].value;
            console.log(turno);
        }
    }
    salBruto = calcularBruto(horas, turno);
    salTotal += salBruto;
    console.log(salTotal);
    mostrarSalario(calcularNeto(salBruto));
}

function calcularBruto(horas, turno) {
    var precioH;
    switch (turno) {
        case 'm':
            precioH = 15;
            break;
        case 't':
            precioH = 17;
            break;
        case 'n':
            precioH = 20;
            break;
        default:
            precioH = 0;
    }

    return horas * precioH;
}

function calcularNeto(salBruto) {
    var salNeto;

    if (salBruto < 600) {
        salNeto = salBruto * 0.92;
    } else if (salBruto > 1000) {
        salNeto = salBruto * 0.88;
    } else {
        salNeto = salBruto * 0.9;
    }

    return salNeto;
}

function mostrarSalario(salNeto){
    document.getElementById("salario").value = salNeto;
}

function limpiar(){
    document.getElementById("horas").value = '';
    document.getElementById("salario").value = '';
}

function finalizar(){
    document.getElementById("principal").style.display = "none";
    document.getElementById("final").style.display = "block";
    document.getElementById("presupuesto").value = salTotal;
}