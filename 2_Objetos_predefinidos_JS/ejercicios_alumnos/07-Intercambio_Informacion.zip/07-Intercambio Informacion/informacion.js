var contenido = '';

function traspasar(url) {

    contenido = document.getElementById('cajaTexto').value;
    sessionStorage.setItem('cont', contenido);
    window.location.href = url;
}

function recuperar() {

    contenido = sessionStorage.getItem('cont');
    document.getElementById('cajaTexto').value = contenido;
}