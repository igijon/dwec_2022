
// Desarrolla un script en el que, según el tamaño de la ventana 
// en la que se visualiza nuestra web, abra una nueva posicionada a 
// (ancho de resolución actual)/8 y (alto de resolución actual)/6, de la esquina superior derecha de la ventana.

function posicionamiento(){
    myWindow= window.open("https://www.google.com/", "nombreVentana", "width=600, height=500");
    // myWindow.moveBy(screen.width/8, screen.height/6);
    // myWindow.moveBy(screen.width-(screen.width/16), screen.height/6);
    myWindow.moveBy(500, screen.height/6);
    console.log(screen.width)
  
}
   

