var cadena = "";
    for (var i = 0; i <= 100; i++) {
        if (i % 7 == 0 || i%10 == 7){
            console.log(cadena + "PUM")
            cadena = "";
        }else{
            cadena = cadena + i + ",";
        }        
    }
console.log(cadena + "PUM");