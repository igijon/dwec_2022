var productos = new Array();
var clave;


/*Tutorial-autoayuda: https://developer.mozilla.org/es/docs/Web/JavaScript/Reference/Global_Objects/Array/sort*/
function aniadirProducto() {
    generarClave()

    var productoNuevo = {
        'nombre': document.getElementById('productoNuevo').value,
        'stock': document.getElementById('stock').value,
        'ID': clave
    };


    productos.push(productoNuevo);
}

function generarClave() {
    var fecha = new Date();

    var a = fecha.getFullYear();
    var d = fecha.getDay();
    var h = fecha.getHours();
    var m = fecha.getMinutes();
    var s = fecha.getSeconds();
    var mil = fecha.getMilliseconds();



    clave = a + d + h + m + s + mil;
}

function eliminarProducto() {
    productos.pop();
}


/*Fuente: https://desarrolloweb.com/articulos/ordenacion-arrays-javascript-sort*/
/*Comparo dos elementos que recibo por parametros, dependiendo de lo que devuelva
coloco el contenido del array */

function comparar(a, b) {
    console.log('prueba');
    if (a.stock == b.stock) {
        return 0;
    }
    if (a.stock < b.stock) {
        return -1;
    }

    return 1;
}


function mostrarProductos() {

    productos.sort(comparar);

    for (var i = 0; i < productos.length; i++) {
        var nombre = productos[i].nombre;
        var st = productos[i].stock;
        var id = productos[i].ID;
        document.body.innerHTML += nombre + ' ,Stock: ' + st + ' ,ID: ' + id + '<br>';
    }


}