var pjVivos = 0; var zombisVivos = 0;
/***************************************************************************************/
/***********************************CONSTRUCTORES***************************************/
/***************************************************************************************/
/**
 * Crea un arma de corto alcance
 * @param {nombre del arma} nombre 
 * @param {daño que inflinge el arma} potencia 
 */
var Arma = function (nombre, potencia) {
    this.nombre = nombre;
    this.potencia = potencia;

    this.getNombre = function () {
        return this.nombre;
    };

    this.getPotencia = function () {
        return this.potencia;
    };

    this.toString = function () {
        return this.nombre + ' (' + this.potencia + 'DMG)';
    };
}

/**
 * Crea un arma de fuego
 * @param {nombre del arma} nombre 
 * @param {daño que inflinge el arma}} potencia 
 * @param {munición máxima del arma} municionMax 
 */
var ArmaDeFuego = function (nombre, potencia, municionMax) {
    Arma.call(this, nombre, potencia);
    this.municionMax = municionMax;
    this.municion = municionMax;

    this.getMunicion = function () {
        return this.municion;
    }

    this.setMunicion = function (municion) {
        this.municion = municion;
    }

    this.getPotencia = function () {
        return this.potencia;
    }

    /**
     * Recarga el arma y establece su munición a la máxima posible
     */
    this.recargar = function () {
        this.municion = municionMax;
        console.log(this.nombre + ' recargada (' + this.municion + ' balas)');
    };

    this.toString = function () {
        return this.nombre + ' (' + this.potencia + 'DMG, ' + this.municion + 'MUN)';
    }
}

/**
 * Crea un personaje con un arma equipada
 * @param {nombre del personaje} nombre 
 * @param {apellido del personaje} apellido 
 * @param {empleo del personaje} empleo 
 * @param {nivel del personaje} nivel 
 * @param {arma que lleva equipada} arma 
 */
var Personaje = function (nombre, apellido, empleo, nivel, arma) {
    this.nombre = nombre;
    this.apellido = apellido;
    this.empleo = empleo;
    this.nivel = nivel;
    this.faccion = 'Humanidad';
    this.arma = arma;
    this.movido = false;
    pjVivos++;

    this.getNombre = function () {
        return this.nombre;
    };

    this.getApellido = function () {
        return this.apellido;
    };

    this.getEmpleo = function () {
        return this.empleo;
    };

    this.getNivel = function () {
        return this.nivel;
    }

    this.getFaccion = function () {
        return this.faccion;
    };

    this.setFaccion = function (faccion) {
        this.faccion = faccion;
    }

    this.getArma = function () {
        return this.arma;
    }

    this.setArma = function (arma) {
        this.arma = arma;
    }

    this.isMovido = function () {
        return this.movido;
    }

    this.setMovido = function (movido) {
        this.movido = movido;
    }

    /**
     * Sube un nivel al personaje
     */
    this.subirNivel = function () {
        console.log(this.nombre + ' sube de nivel');
        this.nivel++;
    }

    /**
     * Comprueba si un personaje está armado
     * @returns true -> está armado; false -> no lo está
     */
    this.estaArmado = function () {
        return this.arma != null;
    }

    /**
     * Equipa un arma a un personaje
     * @param {arma a equipar} arma 
     */
    this.equipar = function (arma) {
        this.arma = arma;
        console.log(this.nombre + ' se ha equipado ' + arma.getNombre());
    };

    /**
     * Establece el arma del personaje a null
     */
    this.tirarArma = function () {
        console.log(this.nombre + ' tira su ' + this.arma.getNombre());
        this.arma = null;
    }

    /**
     * Ataca a un zombi
     * @param {zombi atacado} zombi 
     */
    this.atacar = function (zombi) {
        zombi.recibirPupa(this.arma.getPotencia());
        if (this.arma instanceof ArmaDeFuego) {
            this.arma.setMunicion(this.arma.getMunicion() - 1);
        }
        console.log(this.nombre + ' ha atacado al zombi ' + zombi.getNombre());
    }

    /**
     * Se defiende de un zombi que le ataca
     * @param {zombi atacante} zombi 
     */
    this.defenderse = function (zombi) {
        zombi.recibirPupa(Math.trunc(this.arma.getPotencia() / 2));
        if (this.arma instanceof ArmaDeFuego) {
            this.arma.setMunicion(this.arma.getMunicion() - 1);
        }
        console.log(this.nombre + ' ha defendido del zombi ' + zombi.getNombre());
    }

    this.toString = function () {
        var cad = '<img src="img/personaje.png"><br>';
        cad += this.nombre + ' ' + this.apellido.charAt(0) + '. (nv ' + this.nivel + ')';
        if (this.arma != null) {
            cad += '<br>' + this.arma.toString();
        }
        return cad;
    }
}

/**
 * Crea un zombi genérico, que se mueve sólo por tierra
 * @param {nombre del zombi} nombre 
 * @param {salud del zombi} salud 
 * @param {daño que inflingirá el zombi con cada ataque} potencia 
 */
var Zombi = function (nombre, salud, potencia) {
    this.nombre = nombre;
    this.salud = salud;
    this.potencia = potencia;
    this.movido = false;
    zombisVivos++;

    this.getNombre = function () {
        return this.nombre;
    };

    this.getSalud = function () {
        return this.salud;
    };

    this.getPotencia = function () {
        return this.potencia;
    };

    this.setSalud = function (salud) {
        this.salud = salud;
    };

    this.isMovido = function () {
        return this.movido;
    }

    this.setMovido = function (movido) {
        this.movido = movido;
    }

    /**
     * Resta una cantidad de puntos de salud
     * @param {puntos de salud} num 
     */
    this.recibirPupa = function (num) {
        console.log(this.nombre + ' ha recibido ' + num + ' puntos de daño');
        this.salud -= num;
    }

    /**
     * Ataca a un personaje y lo convierte en zombi, le quita el arma o recibe daño de él, según los casos
     * @param {personaje atacado} pj 
     */
    this.atacar = function (pj) {
        console.log(this.nombre + ' ataca a ' + pj.getNombre());
        //Me prevengo porque una abominación puede atacar 2-3 veces seguidas
        if (pj instanceof Personaje) {
            //Si el personaje está desarmado, se le convierte en zombi
            if (!pj.estaArmado()) {
                pj = this.zombificar(pj);
            } else {
                let arma = pj.getArma();
                //Si su arma es de fuego...
                if (arma instanceof ArmaDeFuego) {
                    //... y no tiene munición...
                    if (arma.getMunicion() <= 0) {
                        //... cara o cruz
                        if (Math.trunc(Math.random() * 2) === 0) {
                            pj = this.zombificar(pj);
                        } else {
                            pj.tirarArma();
                        }
                    } else {
                        pj.defenderse(this);
                    }
                } else {
                    //Si su arma no es de fuego, cara o cruz
                    if (Math.trunc(Math.random() * 2) === 0) {
                        pj = this.zombificar(pj);
                    } else {
                        pj.tirarArma();
                    }
                }
            }
        }
    }

    /**
     * Convierte a un personaje en zombi
     * @param {personaje zombificado} pj 
     */
    this.zombificar = function (pj) {
        var zombiNuevo;
        if (this instanceof ZombiAcuatico) {
            zombiNuevo = new ZombiAcuatico(pj.getNombre(), Math.trunc(pj.getNivel() / 2), Math.trunc(pj.getNivel() / 2));
        } else if (this instanceof Abominacion) {
            zombiNuevo = new Abominacion(pj.getNombre(), Math.trunc(pj.getNivel() / 2), Math.trunc(pj.getNivel() / 2));
        } else {
            zombiNuevo = new Zombi(pj.getNombre(), Math.trunc(pj.getNivel() / 2), Math.trunc(pj.getNivel() / 2));
        }
        pjVivos--;
        console.log(pj.getNombre() + ' se ha convertido en zombi')
        return zombiNuevo;
    }

    this.toString = function () {
        var cad = '<img src="img/zombi.png"><br>'
        cad += 'Zombi ' + this.nombre + ' (' + this.salud + ')';
        return cad;
    }
}

/**
 * Crea un zombi acuático, que se mueve sólo por agua
 * @param {nombre del zombi} nombre 
 * @param {salud del zombi} salud 
 * @param {daño que inflingirá el zombi con cada ataque} potencia 
 */
var ZombiAcuatico = function (nombre, salud, potencia) {
    Zombi.call(this, nombre, salud, potencia);

    this.toString = function () {
        var cad = '<img src="img/zombi_acuatico.png"><br>';
        cad += 'Z. Agua ' + this.nombre + ' (' + this.salud + ')';
        return cad;
    }
}

/**
 * Crea una abominación, que se puede mover tanto por tierra como por agua
 * @param {nombre del zombi} nombre 
 * @param {salud del zombi} salud 
 * @param {daño que inflingirá el zombi con cada ataque} potencia 
 */
var Abominacion = function (nombre, salud, potencia) {
    Zombi.call(this, nombre, salud, potencia);

    //No funciona, así que lo hago en el algoritmo principal
    // /**
    //  * Ataca a un personaje entre 2 y 3 veces
    //  * @param {personaje atacado} pj 
    //  */
    // this.atacar = function (pj) {
    //     let num = Math.trunc(Math.random() * 2) + 2;
    //     for (let i = 0; i < num; i++) {
    //         Zombi.prototype.atacar.call(this, pj);
    //     }
    // }

    this.toString = function () {
        var cad = '<img src="img/abominacion.ico"><br>';
        cad += 'Abominación ' + this.nombre + ' (' + this.salud + ')';
        return cad;
    }
}

/**
 * Crea una casilla vacía de un tipo definido
 * @param {0 -> tierra; 1 -> agua} tipo 
 */
var Casilla = function (tipo) {
    this.tipo = tipo;
    this.ocupante = null;

    this.getOcupante = function () {
        return this.ocupante;
    }

    this.setOcupante = function (ocupante) {
        this.ocupante = ocupante;
    }

    /**
     * Resuelve si la casilla está o no vacía
     * @returns true -> la casilla está vacía; false -> tiene algún ocupante
     */
    this.estaVacia = function () {
        return this.ocupante === null;
    }

    /**
     * Mete un arma, un personaje o un zombi en una casilla si está vacía
     * @param {arma, personaje o zombi} cosa 
     * @returns true -> se ha añadido; false -> no se ha añadido
     */
    this.addCosa = function (cosa) {
        let added = false;

        if (this.ocupante === null) {
            this.ocupante = cosa;
            added = true;
        }
        return added;
    }

    this.toString = function () {
        var cad = '<td class="col-l-2 col-m-2" style="background-color:';
        switch (this.tipo) {
            case 0: cad += 'rgb(169, 136, 55)'; break;
            case 1: cad += 'rgb(114, 135, 220)';
        }
        cad += ';">';
        if (this.ocupante != null) {
            cad += this.ocupante.toString();
        }

        cad += '</td>';
        return cad;
    }
}

/**
 * Crea un mapa de casillas con dimF filas, dimC columnas y dimP planos
 * @param {cantidad de filas} dimF 
 * @param {cantidad de columnas} dimC 
 * @param {cantidad de planos} dimP 
 */
var Mapa = function (dimP, dimF, dimC) {
    this.dimF = dimF;
    this.dimC = dimC;
    this.dimP = dimP;
    this.casillas = new Array(dimP);
    for (let i = 0; i < dimP; i++) {
        this.casillas[i] = new Array(dimF);
        for (let j = 0; j < dimF; j++) {
            this.casillas[i][j] = new Array(dimC);
        }
    }

    /**
     * @returns la cantidad de filas del mapa
     */
    this.getDimF = function () {
        return this.dimF;
    }

    /**
     * @returns la cantidad de columnas del mapa
     */
    this.getDimC = function () {
        return this.dimC;
    }

    /**
     * @returns la cantidad de planos del mapa
     */
    this.getDimP = function () {
        return this.dimP;
    }

    /**
     * Establece un arma, personaje o zombi en una posición de mapa
     * @param {plano} i 
     * @param {posición horizontal} j 
     * @param {posición vertical} k 
     * @param {una casilla} casilla 
     */
    this.setCasilla = function (i, j, k, casilla) {
        this.casillas[i][j][k] = casilla;
    }

    /**
     * @param {plano} i 
     * @param {posición horizontal} j 
     * @param {posición vertical} k 
     * @returns una casilla
     */
    this.getCasilla = function (i, j, k) {
        return this.casillas[i][j][k];
    }

    /**
     * Comprueba si la casilla existe dentro del tablero
     * @param {la posición de la fila} f 
     * @param {la posición de la columna} c 
     * @returns true -> la casilla existe; false -> la casilla no existe
     */
    this.existeCasilla = function (f, c) {
        return f >= 0 && c >= 0 && f < this.dimF && c < this.dimC;
    }

    this.toString = function () {
        var cad = '';
        for (let i = 0; i < this.dimP; i++) {
            cad += '<table class="col-l-5 col-m-5">';
            for (let j = 0; j < this.dimF; j++) {
                cad += '<tr class="row">';
                for (let k = 0; k < this.dimC; k++) {
                    cad += this.getCasilla(i, j, k).toString();
                }
                cad += '</tr>';
            }
            cad += '</table>';
        }
        return cad;
    }
}

/**
 * Contiene todas las funciones para crear objetos
 */
var Factoria = function () {
    /**
     * Crea un arma aleatoria
     * @returns Un objeto tipo Arma o ArmaDeFuego
     */
    this.factoriaArma = function () {
        let nombre; let potencia; let municion;
        let alea = Math.trunc(Math.random() * 100);

        if (alea < 35) {
            nombre = 'Navaja'; potencia = 1;
        } else if (alea < 65) {
            nombre = 'Machete'; potencia = 2;
        } else if (alea < 90) {
            nombre = 'Pistola'; potencia = 3; municion = 6;
        } else {
            nombre = 'Escopeta'; potencia = 5; municion = 2;
        }

        if (alea < 65) {
            return new Arma(nombre, potencia);
        } else {
            return new ArmaDeFuego(nombre, potencia, municion);
        }
    }

    /**
     * Crea un personaje aleatorio
     * @returns Un objeto de tipo Personaje
     */
    this.factoriaPersonaje = function (arma) {
        let nombre; let apellido; let empleo;

        switch (Math.trunc(Math.random() * 6)) {
            case 0: nombre = 'Dani'; break;
            case 1: nombre = 'Malena'; break;
            case 2: nombre = 'Laura'; break;
            case 3: nombre = 'Pablo'; break;
            case 4: nombre = 'Álvaro'; break;
            case 5: nombre = 'David';
        }
        switch (Math.trunc(Math.random() * 6)) {
            case 0: apellido = 'Coello'; break;
            case 1: apellido = 'Díez'; break;
            case 2: apellido = 'Moreno'; break;
            case 3: apellido = 'Santos'; break;
            case 4: apellido = 'Barragán'; break;
            case 5: apellido = 'Loquesea';
        }
        switch (Math.trunc(Math.random() * 6)) {
            case 0: empleo = 'Profe'; break;
            case 1: empleo = 'Policía'; break;
            case 2: empleo = 'Delincuente'; break;
            case 3: empleo = 'En paro'; break;
            case 4: empleo = 'Médico'; break;
            case 5: empleo = 'Chef';
        }

        return new Personaje(nombre, apellido, empleo, 0, this.factoriaArma());
    }

    /**
     * Crea un zombi con parámetros aleatorios
     * @param {0 -> normal; 1 -> acuático; 2 -> abominación} tipo 
     * @returns un zombi con parámetros aleatorios
     */
    this.factoriaZombi = function (tipo) {
        //Elijo el nombre al azar
        var nombre = ''; var salud; var potencia;
        switch (Math.trunc(Math.random() * 6)) {
            case 0: nombre = 'Uuuuugh'; break;
            case 1: nombre = 'Blaaagh'; break;
            case 2: nombre = 'Cereebroos'; break;
            case 3: nombre = 'Eehhrrmm'; break;
            case 4: nombre = 'Aaaarggh'; break;
            case 5: nombre = 'Mmmmmmm';
        }

        switch (tipo) {
            case 0:
                salud = Math.trunc(Math.random() * 5) + 1;
                potencia = Math.trunc(Math.random() * 3) + 2;
                return new Zombi(nombre, salud, potencia);
                break;
            case 1:
                salud = Math.trunc(Math.random() * 3) + 2;
                potencia = Math.trunc(Math.random() * 3) + 1;
                return new ZombiAcuatico(nombre, salud, potencia);
                break;
            case 2:
                salud = Math.trunc(Math.random() * 6) + 5;
                potencia = Math.trunc(Math.random() * 2) + 1;
                return new Abominacion(nombre, salud, potencia);
        }
    }

    /**
     * Crea un mapa de 5x5x2 y le añade 2 personajes, 5 zombis y 1 abominación en cada plano
     * @returns un mapa inicializado
     */
    this.factoriaMapa = function () {
        //Creo el mapa
        var mapa = new Mapa(2, 5, 5);
        //Inicializo cada casilla
        for (let i = 0; i < mapa.getDimP(); i++) {
            for (let j = 0; j < mapa.getDimF(); j++) {
                for (let k = 0; k < mapa.getDimC(); k++) {
                    mapa.setCasilla(i, j, k, new Casilla(i));
                }
            }
        }
        //Meto a los personajes en el plano de tierra
        let restantes = 2;
        while (restantes > 0) {
            let f = Math.trunc(Math.random() * mapa.getDimF());
            let c = Math.trunc(Math.random() * mapa.getDimC());
            if (mapa.getCasilla(0, f, c).addCosa(this.factoriaPersonaje())) {
                restantes--;
            }
        }
        //Meto a los personajes en el plano de agua
        restantes = 2;
        while (restantes > 0) {
            let f = Math.trunc(Math.random() * mapa.getDimF());
            let c = Math.trunc(Math.random() * mapa.getDimC());
            if (mapa.getCasilla(1, f, c).addCosa(this.factoriaPersonaje())) {
                restantes--;
            }
        }
        //Meto a los zombis de tierra
        restantes = 5;
        while (restantes > 0) {
            let f = Math.trunc(Math.random() * mapa.getDimF());
            let c = Math.trunc(Math.random() * mapa.getDimC());
            if (mapa.getCasilla(0, f, c).addCosa(this.factoriaZombi(0))) {
                restantes--;
            }
        }
        //Meto a los zombis de agua
        restantes = 5;
        while (restantes > 0) {
            let f = Math.trunc(Math.random() * mapa.getDimF());
            let c = Math.trunc(Math.random() * mapa.getDimC());
            if (mapa.getCasilla(1, f, c).addCosa(this.factoriaZombi(1))) {
                restantes--;
            }
        }
        //Meto a las abominaciones
        restantes = 1;
        while (restantes > 0) {
            let f = Math.trunc(Math.random() * mapa.getDimF());
            let c = Math.trunc(Math.random() * mapa.getDimC());
            if (mapa.getCasilla(0, f, c).addCosa(this.factoriaZombi(2))) {
                restantes--;
            }
        }
        restantes = 1;
        while (restantes > 0) {
            let f = Math.trunc(Math.random() * mapa.getDimF());
            let c = Math.trunc(Math.random() * mapa.getDimC());
            if (mapa.getCasilla(1, f, c).addCosa(this.factoriaZombi(2))) {
                restantes--;
            }
        }

        return mapa;
    }
}

/***************************************************************************************/
/**************************************AUXILIAR*****************************************/
/***************************************************************************************/
/**
 * Muestra el mapa de juego en el html
 * @param {mapa virtual} mapa 
 */
function mostrarTablero(mapa) {
    document.getElementById('juego').innerHTML = mapa.toString();
}

/**
 * Elige una posición adyacente a la que ocupa un zombi o personaje
 * @param {el mapa completo} mapa 
 * @param {la fila de la posición en la que está el personaje} f 
 * @param {la columna de la posición en la que está el personaje} c 
 * @returns una posición a la que se puede desplazar el personaje
 */
var decidirCasilla = function (mapa, f, c) {
    var destino = new Array(2);
    var decidido = false;

    do {
        //Elijo una posición random adyacente al personaje
        destino[0] = Math.trunc(Math.random() * 3) + f - 1;
        destino[1] = Math.trunc(Math.random() * 3) + c - 1;
        //Si la casilla existe
        if (mapa.existeCasilla(destino[0], destino[1])) {
            //Compruebo que no sea la misma que la de origen
            if (destino[0] != f || destino[1] != c) {
                decidido = true;
            }
        }
    } while (!decidido);

    return destino;
}

/**
 * Lo más parecido que he podido encontrar al Thread.sleep de java
 * https://stackoverflow.com/questions/951021/what-is-the-javascript-version-of-sleep
 * @param {milisegundos pa esperar} ms 
 * @returns 
 */
function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

/***************************************************************************************/
/**************************************PROGRAMA*****************************************/
/***************************************************************************************/
var factoria = new Factoria();
var mapa;
var t; var continuar;

/**
 * Carga todo el código 
 */
function cargar() {
    t = 0; continuar = true;
    //Genero el mapa virtual
    mapa = factoria.factoriaMapa();
    //Muestro la situación inicial del tablero
    mostrarTablero(mapa);
    //Inicio la simulación
    ejecutarSimulacion();
}

/**
 * Comprende toda la simulación
 */
async function ejecutarSimulacion() {
    while (continuar) {
        //Cada 2 segundos, cada personaje se mueve o recarga su arma
        console.log(t);
        if (t % 2 === 0) {
            console.log('Cada dos segundos');
            //Recorro el mapa
            for (let i = 0; i < mapa.getDimP(); i++) {
                for (let j = 0; j < mapa.getDimF(); j++) {
                    for (let k = 0; k < mapa.getDimC(); k++) {
                        //Extraigo la casilla a una variable
                        let casillaOrigen = mapa.getCasilla(i, j, k);
                        //Si encuentro un personaje
                        if (casillaOrigen.getOcupante() instanceof Personaje) {
                            //Lo saco a una variable
                            let pj = casillaOrigen.getOcupante();
                            //Si no se ha movido, entra en acción
                            if (!pj.isMovido()) {
                                //Compruebo si tiene que recargar su arma
                                let recarga = false;
                                //Si está armado...
                                if (pj.estaArmado()) {
                                    let arma = pj.getArma();
                                    //... es un arma de fuego...
                                    if (arma instanceof ArmaDeFuego) {
                                        //... y no tiene munición
                                        if (arma.getMunicion() === 0) {
                                            //Le digo que tiene que recargar
                                            recarga = true;
                                        }
                                    }
                                }
                                //Si tiene que recargar, lo hace
                                if (recarga) {
                                    pj.getArma().recargar();
                                    //Y si no, entra en acción
                                } else {
                                    //Decide la casilla de destino y la saco a una variable
                                    let destino = decidirCasilla(mapa, j, k);
                                    let casillaDestino = mapa.getCasilla(i, destino[0], destino[1]);
                                    //Si no hay nada, se mueve
                                    if (casillaDestino.estaVacia()) {
                                        casillaDestino.setOcupante(pj);
                                        casillaOrigen.setOcupante(null);
                                    } else {
                                        //Si hay algo, extraigo el ocupante a una variable
                                        let ocupante = casillaDestino.getOcupante();
                                        //Si es un personaje, intercambian posiciones
                                        if (ocupante instanceof Personaje) {
                                            casillaDestino.setOcupante(pj);
                                            casillaOrigen.setOcupante(ocupante);
                                            //Si es un arma, se la equipa y se mueve a esa posición
                                        } else if (ocupante instanceof Arma) {
                                            pj.equipar(ocupante);
                                            casillaDestino.setOcupante(pj);
                                            casillaOrigen.setOcupante(null);
                                            //Y si es un zombi, le ataca
                                        } else if (ocupante instanceof Zombi ||
                                            ocupante instanceof ZombiAcuatico ||
                                            ocupante instanceof Abominacion) {
                                            let zombi = ocupante;
                                            //Si el personaje va desarmado, se convierte en zombi
                                            if (!pj.estaArmado()) {
                                                casillaOrigen.setOcupante(zombi.zombificar(pj));
                                            } else {
                                                //Si no, le ataca
                                                pj.atacar(zombi);
                                                //Y si el zombi muere, muevo al personaje a esa casilla
                                                if (zombi.getSalud() <= 0) {
                                                    console.log(pj.getNombre() + ' se ha cargado al zombi ' + zombi.getNombre())
                                                    pj.subirNivel();
                                                    zombisVivos--;
                                                    casillaDestino.setOcupante(pj);
                                                    casillaOrigen.setOcupante(null);
                                                }
                                            }
                                        }
                                    }
                                }
                                pj.setMovido(true);
                            }
                        }
                    }
                }
            }
        }
        //Cada 5 segundos, cada zombi se mueve
        if (t % 5 === 0 && t != 0) {
            console.log('Cada cinco segundos');
            //Recorro el mapa
            for (let i = 0; i < mapa.getDimP(); i++) {
                for (let j = 0; j < mapa.getDimF(); j++) {
                    for (let k = 0; k < mapa.getDimC(); k++) {
                        //Si en la casilla hay un zombi
                        let casillaOrigen = mapa.getCasilla(i, j, k);
                        if (casillaOrigen.getOcupante() instanceof Zombi ||
                            casillaOrigen.getOcupante() instanceof ZombiAcuatico ||
                            casillaOrigen.getOcupante() instanceof Abominacion) {
                            let zombi = casillaOrigen.getOcupante();
                            //Si no se ha movido, entra en acción
                            if (!zombi.isMovido()) {
                                //Elige una casilla de destino
                                let destino = decidirCasilla(mapa, j, k);
                                let casillaDestino = mapa.getCasilla(i, destino[0], destino[1]);
                                //Si no hay nada, se mueve
                                if (casillaDestino.estaVacia()) {
                                    casillaDestino.setOcupante(zombi);
                                    casillaOrigen.setOcupante(null);
                                } else {
                                    //Si hay algo, el zombi actuará de una u otra forma según lo que haya
                                    let ocupante = casillaDestino.getOcupante();
                                    //Si es un arma u otro zombi, se intercambian posiciones
                                    if (ocupante instanceof Arma || ocupante instanceof Zombi ||
                                        ocupante instanceof ZombiAcuatico || ocupante instanceof Abominacion) {
                                        casillaDestino.setOcupante(zombi);
                                        casillaOrigen.setOcupante(ocupante);
                                    } else if (ocupante instanceof Personaje) {
                                        //Si es un personaje, el zombi le ataca
                                        if (zombi instanceof Abominacion) {
                                            for (let l = 0; l < Math.trunc(Math.random() * 2) + 2; l++) {
                                                zombi.atacar(ocupante);
                                            }
                                        } else {
                                            zombi.atacar(ocupante);
                                        }
                                        if (zombi.getSalud() <= 0) {
                                            console.log(ocupante.getNombre() + ' se ha cargado al zombi ' + zombi.getNombre())
                                            ocupante.subirNivel();
                                            zombisVivos--;
                                            casillaOrigen.setOcupante(null);
                                        }
                                    }
                                }
                                zombi.setMovido(true);
                            }
                        }
                    }
                }
            }
        }
        //Cada 20 segundos, se colocan 2 items en posiciones aleatorias
        if (t % 20 === 0 && t != 0) {
            console.log('Cada veinte segundos');
            let items = 2;
            while (items > 0) {
                let p = Math.trunc(Math.random() * mapa.getDimP());
                let f = Math.trunc(Math.random() * mapa.getDimF());
                let c = Math.trunc(Math.random() * mapa.getDimC());
                if (mapa.getCasilla(p, f, c).addCosa(factoria.factoriaArma())) {
                    console.log('Ha caído un arma en (' + p + ', ' + f + ', ' + c + ')');
                    items--;
                }
            }
        }

        /*Ahora recorro todas las casillas para permitir que los personajes y zombis puedan moverse de nuevo.
        Lo hago antes del cambio de plano para que puedan moverse de plano.
        Esto hace que, el turno en el que cambian de plano, ni humanos ni abominaciones pueden moverse,
        pero zombis de agua y de tierra sí*/
        for (let i = 0; i < mapa.getDimP(); i++) {
            for (let j = 0; j < mapa.getDimF(); j++) {
                for (let k = 0; k < mapa.getDimC(); k++) {
                    let casilla = mapa.getCasilla(i, j, k);
                    if (!casilla.estaVacia()) {
                        let ocupante = casilla.getOcupante();
                        if (ocupante instanceof Personaje || ocupante instanceof Zombi
                            || ocupante instanceof ZombiAcuatico || ocupante instanceof Abominacion) {
                            ocupante.setMovido(false);
                        }
                    }
                }
            }
        }

        //Cada 30 segundos, todos los personajes y abominaciones cambian de plano
        if (t % 30 === 0 && t != 0) {
            console.log('Cada treinta segundos');
            //Recorro el mapa
            for (let i = 0; i < mapa.getDimP(); i++) {
                for (let j = 0; j < mapa.getDimF(); j++) {
                    for (let k = 0; k < mapa.getDimC(); k++) {
                        //Si encuentro un personaje o una abominación, lo cambio de plano
                        let casilla = mapa.getCasilla(i, j, k);
                        if (!casilla.estaVacia()) {
                            let ocupante = casilla.getOcupante();
                            if (ocupante instanceof Personaje || ocupante instanceof Abominacion) {
                                if (!ocupante.isMovido()) {
                                    let cambiado = false;
                                    //Elijo una casilla al azar del plano contrario y añado el ocupante
                                    while (!cambiado) {
                                        let f = Math.trunc(Math.random() * mapa.getDimF());
                                        let c = Math.trunc(Math.random() * mapa.getDimC());
                                        let p = i == 0 ? 1 : 0;
                                        let casillaDestino = mapa.getCasilla(p, f, c);
                                        if (casillaDestino.addCosa(ocupante)) {
                                            console.log(ocupante.getNombre() + ' ha cambiado de plano');
                                            casilla.setOcupante(null);
                                            cambiado = true;
                                        }
                                    }
                                    ocupante.setMovido(true);
                                }
                            }
                        }
                    }
                }
            }
        }

        mostrarTablero(mapa);

        if (pjVivos === 0 || zombisVivos === 0) {
            continuar = false;
        }

        t++;
        await sleep(1000);
    }
    if (pjVivos === 0) {
        alert('La humanidad está condenada');
    } else if (zombisVivos === 0) {
        alert('La humanidad sobrevivirá otro día más');
    }
    mostrarTablero(mapa);
}