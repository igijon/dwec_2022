// 3. Parking

// Crear una función que memorice los valores calculados previamente.
// Debe aparecer una función que memorice el dinero a pagar por un conductor según el tiempo que ha estado estacionado.
// El tiempo (minutos) que ha estacionado se envía por parámetro a la función.
// Cada minuto cuesta 12,05cts.

function entradaDatos(){
    let minutos=document.getElementById('minutos').value;
    document.getElementById("precio").innerHTML=("Precio = " + memor(minutos) + "€");
}

function memor(minutos){

    var precioMinutos = 0.1205;

    if(!memor.cache) {          // si no existe la caché la creamos
        memor.cache = {}; 
    }
  
    if(memor.cache[minutos] != null) {   // el precio ya se ha calculado y se almacena en nuestra caché
        return "<b>" + memor.cache[minutos].toFixed(2) + "</b>"; // devolvemos el valor guardado en caché (reduciendo a 2 el número de decimales mostrados)
    }
  
    var calcuPrecio = (minutos * precioMinutos) // lo calculamos porque no tenemos el resultado
    memor.cache[minutos] = calcuPrecio;         // lo almacenamos en la caché
    return calcuPrecio.toFixed(2);              // devolvemos el valor calculado (reduciendo a 2 el número de decimales mostrados)
}





