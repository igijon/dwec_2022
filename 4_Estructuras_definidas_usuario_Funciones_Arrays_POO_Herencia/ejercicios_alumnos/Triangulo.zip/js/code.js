/**
 * El objetivo de la actividad es crear una función JavaScript que utilice funciones
 * anidadas para dibujar un triángulo de asteriscos.
 * En la actividad debe aparecer una función que dado un número entero ('num')
 * dibuje un triángulo rectángulo, donde cada una de las caras del triángulo debe tener 
 * 'num' asteriscos. Para realizar esta actividad se debe utilizar una estructura anidada de funciones.
 */

function pintarTriangulo (x) {

    function pintarPiso(y) {
        var p = document.createElement('p');
        var t = '';
        for (let j = 0; j < parseInt(y); j++) {
            t += '*';
        }
        p.innerHTML = t;
        document.getElementById('piramide').appendChild(p);
    }

    function borrarAnterior() {
        document.getElementById('piramide').innerHTML = '';
    }

    borrarAnterior();

    for (let i = 1; i < (parseInt(x) + 1); i++) {
        pintarPiso(i);
    }
}

