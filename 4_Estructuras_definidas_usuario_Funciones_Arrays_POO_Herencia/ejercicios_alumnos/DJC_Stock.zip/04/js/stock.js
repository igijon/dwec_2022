var cont = 1;
var productos = [];

function Producto(stock) {
    this.id = 'p' + cont;
    this.stock = stock;
    this.vendidos = 0;
    cont++;
}

/**
 * Según el valor que reciba, llama a la función con el vector ordenado de una u otra forma
 * @param { * num = 0 -> ver productos en orden original
 * num = 1 -> verlos ordenados por stock
 */
function visualizar(num) {
    var prod = productos.slice();
    switch (num) {
        case 0: verStock(prod); break;
        case 1: verStock(prod.sort(compararStocks));
    }
}

/**
 * Muestra por pantalla el listado de productos: su id y el número de unidades
 * También refleja el listado en una lista desplegable
 */
function verStock(array) {
    var listado = "<ul>";
    var options = '';
    for (x = 0; x < array.length; x++) { //productos[0]=5; productos[1]=12; productos[2]=27;
        listado += "<li>" + array[x].id + " tiene " + array[x].stock + " unidades";
        options += '<option value="' + productos[x].id + '">' + productos[x].id + '</option>';
    }
    document.getElementById('idProducto').innerHTML = options;
    listado += "</ul>";
    document.getElementById("listado").innerHTML = listado;
}

/**
 * Amplía el stock, generando nuevos productos y concatenando éstos al array
 * de productos. Finalmente los muestra.
 */
function ampliarStock() {
    var nuevoStock = generarProductos();
    productos = productos.concat(nuevoStock);
    verStock(productos);
}

/**
 * 
 * @param {número de productos a generar} num
 * Si no nos indican número de productos, genera aleatoriamente entre 0 y 5.
 * Si nos indican el número, generará dicho número de productos. 
 */
function generarProductos(num) {
    if (arguments.length === 0) {
        num = Math.floor((Math.random() * 5) + 1); //Math.round(4.7) => 5; Math.floor(4.7) => 4
    }
    var p = [];
    for (x = 0; x < num; x++) //num = 5
        p[x] = new Producto(Math.floor((Math.random() * 100))); //Genera el número de unidades del producto de forma aleatoria
    return p; //p[0]=23; p[1]=45; ... p[4]=34; 5 productos
}

/**
 * Genera un número de productos iniciales
 */
onload = function () {
    productos = generarProductos(10);
};

/**
 * Añade un producto al final del array con un stock definido por el usuario
 */
function addProducto() {
    let stock = document.getElementById('stockProdAdded').value;
    if (stock > 0) {
        let prod = new Producto(stock);
        productos.push(prod);
        verStock(productos);
    } else {
        alert("El producto debe tener un stock mayor que 0")
    }
}

/**
 * Elimina el último producto del array
 */
function eliminarUltimo() {
    if (productos.length > 0) {
        alert(productos.pop().id + ' eliminado');
    } else {
        alert('No quedan productos por eliminar');
    }
    verStock(productos);
}

/**
 * Ordena los productos según stock
 */
function ordenar() {
    verStock(productos.sort(compararStocks));
}

/**
 * Función auxiliar que establece los criterios de ordenación por stock 
 */
function compararStocks(a, b) {
    const stockA = a.stock;
    const stockB = b.stock;

    let comp = 0;
    if (stockA < stockB) {
        comp = 1;
    } else if (stockB < stockA) {
        comp = -1;
    }
    return comp;
}

/**
 * Esta función suma el stock comprado a las ventas y lo resta del stock
 */
function comprar() {
    let id = document.getElementById('idProducto').value;
    let prod = buscarProducto(id);
    let stockComprado = parseInt(document.getElementById('stockProdComprado').value);
    if (prod == null) {
        alert("No has seleccionado ningún producto");
    } else {
        if (stockComprado <= 0 || isNaN(stockComprado)) {
            alert("El stock a comprar debe ser mayor que 0");
        } else if (stockComprado > prod.stock) {
            alert("No tenemos tanto stock de " + id);
        } else {
            prod.stock -= stockComprado;
            prod.vendidos += stockComprado;
            verStock(productos);
            verRanking();
        }
    }
}

/**
 * Busca un producto en el array de productos usando la id como clave
 * @param {*} id 
 * @returns producto correspondiente a la id
 */
function buscarProducto(id) {
    let encontrado = false;
    let prod;
    let i = 0;

    while (i < productos.length && !encontrado) {
        if (id == productos[i].id) {
            prod = productos[i];
            encontrado = true;
        } else {
            i++;
        }
    }
    return prod;
}

/**
 * Muestra un ranking de los productos más vendidos ordenados de mayor a menor venta
 */
function verRanking() {
    var listado = "<ul>";
    var prodOrdVentas = productos.slice().sort(compararVentas);
    for (x = 0; x < prodOrdVentas.length; x++) { //productos[0]=5; productos[1]=12; productos[2]=27;
        listado += "<li>" + prodOrdVentas[x].id + " ha vendido " + prodOrdVentas[x].vendidos + " unidades";
    }
    listado += "</ul>"
    document.getElementById("listadoVentas").innerHTML = listado;
}

/**
 * Función auxiliar que establece los criterios para ordenar de mayor a menor número de ventas
 */
function compararVentas(a, b) {
    const stockA = a.vendidos;
    const stockB = b.vendidos;

    let comp = 0;
    if (stockA < stockB) {
        comp = 1;
    } else if (stockB < stockA) {
        comp = -1;
    }
    return comp;
}