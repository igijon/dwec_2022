/**
 * 
 * El objetivo de la actividad es crear un reloj utilizando funciones definidas por el programador y la función setTimeout.
 * En la actividad debe aparecer una función que escriba la hora actual por pantalla. Cada medio segundo se actualizará
 * para dar la sensación de que realmente estamos visualizando un reloj. Este reloj debe tener el siguiente formato: HH: MM: SS
 */

function getTime () {
    var time = new Date();
    var h = time.getHours() >= 10 ? time.getHours() : '0' + time.getHours();
    var m = time.getMinutes() >= 10 ? time.getMinutes() : '0' + time.getMinutes();
    var s = time.getSeconds() >= 10 ? time.getSeconds() : '0' + time.getSeconds();
    var separator = parseInt(s) % 2 == 0 ? ' ' : ':';
    return h + separator + m + separator + s;
}

function start () {
    document.getElementById("reloj").innerHTML = getTime();
    setTimeout(start, 500);
}


